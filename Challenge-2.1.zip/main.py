class BankAccount:
    def __init__(self, account_number, account_holder_name, initial_balance=0.0):
        self.account_number = account_number
        self. account_holder_name = account_holder_name
        self.initial_balance = initial_balance

    def deposit(self, amount):
        if amount > 0:
          self.initial_balance += amount
          print("Deposited ${}. New balance: ${}".format(amount,self.initial_balance))
        else:
          print("Invalid deposit amount.")

    def withdraw(self, amount):
        if amount > 0 and amount <= self.initial_balance:
            self.initial_balance -= amount
            print("Withdrew ${}. New balance: ${}".format(amount,self.initial_balance))
        else:
            print("Invalid withdrawal amount or insufficient balance.")

    def display_balance(self):
      print("Account balance for {} (Account #{}): ${}".format(self.account_number, self.account_holder_name, self.initial_balance))


# Create an instance of the BankAccount class
account = BankAccount(12344555,"jack",12333)


#Test deposit and withdrawal functionality
account.display_balance()
account.deposit(500.0)
account.withdraw(200.0)
account.withdraw(20000.0)
account.display_balance()